#!/bin/sh
DEBUG=engine,engine:* DEBUG_DEPTH=10 DEBUG_SHOW_HIDDEN=enabled NODE_ENV=debug node app.js

