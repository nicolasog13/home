#!/bin/sh
NODE_ENV=production SS_ENV=production node app.js

