module.exports = {
  extends: ["standard", "prettier"],
  plugins: ["standard", "promise"],
  parserOptions: {
    ecmaVersion: 2017
  }
};
