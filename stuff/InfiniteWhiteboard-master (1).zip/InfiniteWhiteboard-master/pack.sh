#!/bin/sh
SS_PACK=1 SS_ENV=production node app.js
